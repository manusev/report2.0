# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Parser de TousSports.info para Movie Ultra 7K
# Version 0.1 (05.05.2014)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a Juarrox


import plugintools, xbmcplugin, datetime

from __main__ import *

from resources.tools.msg import *


def live9(params):
    plugintools.modo_vista("biglist")
    plugintools.log("[%s %s] Iniciando Live9 ... " % (addonName, addonId))

    filename = 'ultrasports.m3u'
    ultrasp = open(temp + filename, "a")

    from datetime import datetime
    # Calculando día y hora actual
    ahora = datetime.now()
    mes = ahora.month
    if mes <= 9:
        mes = '0'+str(ahora.month)
    time_now = str(ahora.day) + '/' + mes;time_now=time_now.strip()

    #plugintools.add_item(action="", title= '[COLOR blue][B]TOU[COLOR white]SS[COLOR red]PORTS [/B][/COLOR]', url = "", thumbnail = "" , fanart = "", folder = False, isPlayable = False)
    #plugintools.add_item(action="tous2", title= '[COLOR lightyellow]Click aquí para ver [I][B]canales LIVE[/B][/I][/COLOR]', url = "", thumbnail = "" , fanart = "", folder = True, isPlayable = False)

    url = 'http://live9.net/'
    referer = 'http://live9.net/'

    data = gethttp_referer_headers(url,referer)
    #plugintools.log("data= "+data)

    #dia_prog = plugintools.find_single_match("<h4>(.*?)</h4>")

    matches = plugintools.find_single_match(data, '2015</h4>(.*?)</body>')
    plugintools.log("matches= "+matches)
    time_past=""

    event = plugintools.find_multiple_matches(matches, '(.*?)</a>')
    
    for entry in event:
        plugintools.log("entry= "+entry)
        if time_past == "":
            time_past = 0            
        sport_event = plugintools.find_single_match(entry, '<b>(.*?)</b>').strip()
        time_event = plugintools.find_single_match(entry, '(.*?)<font');time_event=time_event.replace('<div class="list">', "").replace(" ", "").strip()
        plugintools.log("time_event= "+time_event)
        hora_event = time_event[0:2]
        plugintools.log("hora_event= "+hora_event)
        title_event = plugintools.find_single_match(entry, '</font> (.*?)<a').strip()
        url_event = plugintools.find_single_match(entry, '<a href="([^"]+)').strip()
        ch_event = plugintools.find_single_match(entry, '">Channel([^\n]+)');ch_event='Channel'+ch_event
        url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url='+url_event+'%26referer=http://live9.net'
        title = '[COLOR gold]'+time_now+'[/COLOR][COLOR orange][B] '+time_event+'[/B][/COLOR][COLOR lightyellow] '+sport_event +': '+ title_event+ '('+ch_event+')[/COLOR][COLOR lightgreen][I] [Live9][/I][/COLOR]'
        plugintools.log("time_event= "+time_event)
        plugintools.log("sport_event= "+sport_event)
        plugintools.log("url_event= "+url_event)        
        #plugintools.add_item(action="play", title=title, url=url, thumbnail="", fanart="", folder=False, isPlayable=False)
        ultrasp.write("Title:"+title+"\nAction:play\nURL:"+url+"\n\n")
        

    ultrasp.close()
    plugintools.modo_vista("biglist")     
        
        
  	
def gethttp_referer_headers(url,referer):
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_3) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.65 Safari/537.31"])
    request_headers.append(["Referer", referer])
    body,response_headers = plugintools.read_body_and_headers(url, headers=request_headers);
    try: r='\'set-cookie\',\s\'([^;]+.)';jar=plugintools.find_single_match(str(response_headers),r);jar=getjad(jar);
    except: pass
    try: r='\'location\',\s\'([^\']+)';loc=plugintools.find_single_match(str(response_headers),r);
    except: pass
    if loc:
     request_headers.append(["Referer",url]);
     if jar: request_headers.append(["Cookie",jar]);#print jar
     body,response_headers=plugintools.read_body_and_headers(loc,headers=request_headers);
     try: r='\'set-cookie\',\s\'([^;]+.)';jar=plugintools.find_single_match(str(response_headers),r);jar=getjad(jar);
     except: pass
     plugintools.modo_vista("biglist")
    return body
