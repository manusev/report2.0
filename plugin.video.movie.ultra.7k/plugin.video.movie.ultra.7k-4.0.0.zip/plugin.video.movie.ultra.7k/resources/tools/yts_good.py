# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Movie Ultra 7K Parser de http://yts.to/
# Version 0.1 (2015.10.14)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)


import os
import sys
import urllib
import urllib2
import re

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

import re,urllib,urllib2,sys,requests
import plugintools

from resources.tools.resolvers import *

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

thumbnail = 'http://i1-news.softpedia-static.com/images/news2/YIFY-Torrents-Becomes-YTS-as-Founder-Retires-420306-2.png'
fanart = 'http://theartmad.com/wp-content/uploads/2015/04/Film-Reel-Wallpaper-Hd-2.jpg'
referer = 'http://yts.to/'

web = "http://yts.to/browse-movies"

#Defino los parametros de la búsqueda (no me hace falta de momento)
calidad    = "all"
genero     = "all"
puntuacion = "0"
orden      = "latest"


def yts0(params):
    plugintools.log('[%s %s] Parseando YTS.TO %s' % (addonName, addonVersion, repr(params)))

    r=requests.get(web)
    data=r.content

    plugintools.add_item(action="",title="[COLOR lightgreen][B]PARSER DE YTS.TO[/B][/COLOR]",thumbnail=thumbnail, fanart=fanart, folder=False, isPlayable=False)
    plugintools.add_item(action="",title="",thumbnail=thumbnail, fanart=fanart, folder=False, isPlayable=False)

    plugintools.add_item(action="yts_seccion",title="[COLOR lightblue][B]Recientes[/B][/COLOR]",url=web,thumbnail=thumbnail, fanart=fanart,folder=True,isPlayable=False)
    plugintools.add_item(action="",title="",thumbnail=thumbnail, fanart=fanart, folder=False, isPlayable=False)

    plugintools.add_item(action="yts_seccion",title="[COLOR lightblue][B]Últimas 3D[/B][/COLOR]", url="http://yts.to/browse-movies/0/3d/all/0/latest",thumbnail=thumbnail, fanart=fanart, folder=True, isPlayable=False)
    plugintools.add_item(action="", title="", url="",thumbnail=thumbnail,fanart=fanart, folder=False, isPlayable=False)

    plugintools.add_item(action="yts_filtro_busqueda_1",title="[COLOR lightblue][B]Filtro de búsqueda combinado[/B][/COLOR]",url="",thumbnail=thumbnail, fanart=fanart,folder=True,isPlayable=False)


def yts_filtro_busqueda_1(params):
    r=requests.get(web)
    data=r.content

    plugintools.add_item(action="",title="[COLOR yellow][I]Escoja un género[/I][/COLOR]",folder=True,isPlayable=False)
    plugintools.add_item(action="",title="",folder=True,isPlayable=False)

    bloque_genero = plugintools.find_single_match(data, '<select name="genre">(.*?)</select>')
    lista_generos = plugintools.find_multiple_matches(bloque_genero,'<option value="(.*?)"')
    
    enlace_original = 'http://yts.to/browse-movies/0/all/genero/puntuacion/orden'

    for item in lista_generos:
        enlace = enlace_original.replace("genero",item)
        plugintools.add_item(action="yts_filtro_busqueda_2",title=item,url=enlace,folder=True,isPlayable=False)


def yts_filtro_busqueda_2(params):
    r=requests.get(web)
    data=r.content
    enlace_original = params.get("url")

    plugintools.add_item(action="",title="[COLOR yellow][I]Escoja una puntución mínima[/I][/COLOR]",folder=True,isPlayable=False)
    plugintools.add_item(action="",title="",folder=True,isPlayable=False)

    bloque_puntuacion = plugintools.find_single_match(data, '<select name="rating">(.*?)</select>')
    lista_puntuacion = plugintools.find_multiple_matches(bloque_puntuacion,'<option value="(.*?)"')

    for item in lista_puntuacion:
        enlace = enlace_original.replace("puntuacion",item)
        plugintools.add_item(action="yts_filtro_busqueda_3", title=item,url=enlace,folder=True, isPlayable=False)


def yts_filtro_busqueda_3(params):
    r=requests.get(web)
    data=r.content
    enlace_original = params.get("url")

    plugintools.add_item(action="",title="[COLOR yellow][I]Escoja el orden[/I][/COLOR]",folder=True,isPlayable=False)
    plugintools.add_item(action="",title="",folder=True,isPlayable=False)

    bloque_orden = plugintools.find_single_match(data, '<select name="order_by">(.*?)</select>')
    lista_orden = plugintools.find_multiple_matches(bloque_orden,'<option value="(.*?)"')

    for item in lista_orden:
        enlace = enlace_original.replace("orden",item)
        plugintools.add_item(action="yts_filtro_busqueda_4", title=item,url=enlace,folder=True, isPlayable=False)


def yts_filtro_busqueda_4(params):
    r=requests.get(web)
    data=r.content
    enlace_original = params.get("url")

    plugintools.add_item(action="",title="[COLOR yellow][I]Escoja el formato[/I][/COLOR]",folder=True,isPlayable=False)
    plugintools.add_item(action="",title="",folder=True,isPlayable=False)

    bloque_formato = plugintools.find_single_match(data, '<select name="quality">(.*?)</select>')
    lista_formato  = plugintools.find_multiple_matches(bloque_formato,'<option value="(.*?)"')

    for item in lista_formato:
        enlace = enlace_original.replace("orden",item)
        #plugintools.log('>>> TERCER FILTRO - URL CONSTRUIDA:'+enlace)
        titulo = enlace.replace("http://yts.to/browse-movies/0/","")

        plugintools.add_item(action="yts_seccion",title=item,url=enlace,folder=True,isPlayable=False)


def yts_seccion(params):

    url = params.get("url")
    r = requests.get(url)
    data=r.content

    #titulo_seccion = params.get("title")
    #plugintools.add_item(action="", title="[COLOR yellow][B]" + titulo_seccion + "[/B][/COLOR]", url="", thumbnail="", folder=False, isPlayable=False)
    #plugintools.add_item(action="", title="", url="", thumbnail="", folder=False, isPlayable=False)

    bloque_peliculas = plugintools.find_single_match(data,'<section>(.*?)</section>')
    lista_peliculas = plugintools.find_multiple_matches(bloque_peliculas,'browse-movie-wrap(.*?)</div>  </div> </div>')

    for item in lista_peliculas:
        enlace_peli = plugintools.find_single_match(item,'<a href="(.*?)"')
        titulo_peli = plugintools.find_single_match(item,'class="browse-movie-title">(.*?)</a>')
        poster_peli = plugintools.find_single_match(item,'src="(.*?)"')
        anno_peli   = plugintools.find_single_match(item,'class="browse-movie-year">(.*?)</div>')

        plugintools.add_item(action="yts_ficha_pelicula", title=titulo_peli, url=enlace_peli, thumbnail=poster_peli, folder=True, isPlayable=False)


    #Añadimos enlace a la siguiente página si existe
    paginacion = plugintools.find_single_match(data,'class="tsc_pagination tsc_paginationA tsc_paginationA06(.*?)<div class="hidden-md hidden-lg">')
    lista_enlaces = plugintools.find_multiple_matches(paginacion,'<li>(.*?)</li>')
    for item in lista_enlaces:
        enlace   = plugintools.find_single_match(item,'<a href="(.*?)"')
        etiqueta = plugintools.find_single_match(item,'>(.*?)</a>')
        if 'Next' in etiqueta:
            plugintools.log('>>> FUNCIONA')
            plugintools.add_item(action="yts_seccion", title="[COLOR blue][I]> Siguiente página[/I][/COLOR]", url=enlace, folder=True,isPlayable=False)


def yts_ficha_pelicula(params):

    url       = params.get("url")
    thumbnail = params.get("thumbnail")
    titulo    = params.get("title")

    addon_magnet = plugintools.get_setting("addon_magnet")

    r = requests.get(url)
    data = r.content; # print data

    #Cogemos el fanart del primer screenshot
    bloque_screenshots = plugintools.find_single_match(data, '<div id="screenshots"(.*?)<div id="movie-sub-info" class="row">')
    fanart = plugintools.find_single_match(bloque_screenshots, '<img src="(.*?)"')
    fanart = fanart.replace('medium-screenshot','large-screenshot')

    #Escribimos el título de la peli
    #plugintools.add_item(action="", title="[COLOR lightblue][B] "+titulo+" [/B][/COLOR]", url="", thumbnail=thumbnail, fanart=fanart, folder=False, isPlayable=False)
    #plugintools.add_item(action="", title="", url="", thumbnail=thumbnail, fanart=fanart, folder=False, isPlayable=False)

    #Sacamos los enlaces a los magnets
    lista_enlaces = plugintools.find_multiple_matches(data, '<div class="modal-torrent">(.*?)</span></a> </div>')

    for item in lista_enlaces:
        calidad = plugintools.find_single_match(item,'<span>(.*?)</span>')
        enlace = plugintools.find_single_match(item,'href="magnet(.*?)"')
        enlace = 'magnet' + enlace  

        plugintools.add_item(action="yts2", title= 'Ver [COLOR yellow]' + titulo + '[/COLOR] en formato [COLOR orange][B]' + calidad + '[/B][/COLOR]', url=enlace, thumbnail=thumbnail, fanart=fanart, folder=False, isPlayable=True)

    #Buscamos el trailer (no funciona la llamada de momento)
    enlace_trailer = plugintools.find_single_match(data,'<a class="youtube cboxElement" href="//(.*?)"')
    enlace_trailer = '---http://' + enlace_trailer
    plugintools.add_item(action="", title="", url="", thumbnail=thumbnail, fanart=fanart, folder=False, isPlayable=False)
    plugintools.add_item(action="play", title='Ver el trailer de [COLOR yellow]' + titulo + '[/COLOR]', url=enlace_trailer, fanart=fanart, folder=False, isPlayable=True)


def yts2(params):
    
    plugintools.log("[%s %s] obteniendo url %s " % (addonName, addonVersion, repr(params)))   
    url = params.get("url")
    addon_magnet = plugintools.get_setting("addon_magnet")

    if addon_magnet == "0":  # Stream (por defecto)
        url = 'plugin://plugin.video.stream/play/'+url
    elif addon_magnet == "1":  # Pulsar
        url = 'plugin://plugin.video.pulsar/play?uri=' + url
    elif addon_magnet == "2":  # Kmediatorrent
        url = 'plugin://plugin.video.kmediatorrent/play/'+url

    #url = urllib.unquote_plus(url)
    plugintools.log("Magnet URL= "+url)
    plugintools.play_resolved_url(url)       
