# -*- coding: utf-8 -*-
#--------------------------------------------------------
#  Movie Ultra 7K
# Version 0.0.4 (29.11.2014)
#   !!! Intentar NO compartir este archivo !!!
#--------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
#--------------------------------------------------------

from __main__ import *
from cric import *
thumb="http://portaltv.ro/file/logo.png"
fanart="http://sd.keepcalm-o-matic.co.uk/i/keep-calm-and-love-romania-73.png"
baseurl='http://portaltv.ro/';
messs='plugintools.message("ERROR","[COLOR=yellow]Cambios en la web[/COLOR]","[COLOR=red](avisar en el foro)[/COLOR]")'
nolink='plugintools.message("ATENCION","[COLOR=yellow]Canal sin emicion[/COLOR]","[COLOR=red](no hay enlaces)[/COLOR]")'
pxmess='plugintools.message("ATENCION","[COLOR=yellow]Necesita proxy RDS!!![/COLOR]","[COLOR=red](se intenta abrir)[/COLOR]")'
epgmenu=plugintools.get_setting("portalepg");mssg='creando servicio P2P...';timp=3000;
dlg="xbmcgui.Dialog().notification('ESPERE',mssg,icon,timp)"

def portro0(params):
  xbmcgui.Dialog().notification('ESPERE','buscando categorias...',icon,1000)
  plugintools.add_item(action='portro0',title="[COLOR=blue][B]Por[COLOR=yellow]tal[COLOR=red] TV[/B][/COLOR]",thumbnail='http://portaltv.ro/file/logo.png',fanart='http://sd.keepcalm-o-matic.co.uk/i/keep-calm-and-love-romania-73.png',folder=True);
  ref=baseurl;body='';jar='';body,jar=cric2(baseurl,ref,body,jar);
  try:
   #r='<div\sclass="meniu">(.*?)<\/div>';y=plugintools.find_single_match(body,r);
   r='class="([^"]+)">([^<]+)</a>';y=plugintools.find_multiple_matches(body,r);y=y[:-1]
   for x in y:
    q=x[0].split();
    plugintools.add_item(action='portro1',title=str(x[1]),url=q[0],thumbnail=thumb,fanart=fanart,folder=True,isPlayable=False);
  except: exec(messs)

def portro1(params):
 xbmcgui.Dialog().notification('ESPERE','buscando canales...',icon,3000)
 tit='[COLOR=green]'+params.get('title')+'[/COLOR]';
 plugintools.add_item(action='',title=tit,url='',thumbnail=thumb,fanart=fanart,folder=False,isPlayable=False);
 jurl='http://portaltv.ro/file/over.js'
 try:
  ref=baseurl;body='';jar='';body,jar=cric2(jurl,ref,body,jar);
 except: exec(messs)
 try:
  url=params.get('url');
  r='\.'+url+'.*?\{\$\(\'\.([^\']+)';y=plugintools.find_single_match(body,r);
  body,jar=cric2(baseurl,ref,body,jar);
  r='<li\sclass="?\'?all\spl\s'+y+'"?\'?.*?<a\sclass="?\'?nam"?\'?\shref="?\'?([^\'"]+).*?class="?\'?name"?\'?>([^<]+)';
  y=plugintools.find_multiple_matches(body,r);
  for x in y:
   if epgmenu=='true':
     epg=baseurl+x[0];bode='';bode,jar=cric2(epg,ref,bode,jar);
     r='class="?\'?epg"?\'?\sid="?\'?lista"?\'?.*?<font>([^<]+).*?>([^<]+)';
     try: epg=plugintools.find_multiple_matches(bode,r);epg='\n[COLOR=yellow]'+epg[0][0]+'[COLOR=red]('+epg[0][1]+')[/COLOR]'
     except: epg='';pass
   else: epg='';
   tit='[COLOR=cyan]'+x[1].upper()+'[/COLOR]'
   plugintools.add_item(action='portro2',title=str(tit+epg),url=str(x[0]),thumbnail=thumb,fanart=fanart,folder=False,isPlayable=False);
 except: exec(messs)

def portro2(params):
 tit=params.get('title');tit=re.sub('(\n\[COLOR=yellow\].*?\[\/COLOR\])','',tit);
 plugintools.add_item(action='',title=tit,url='',thumbnail=thumb,fanart=fanart,folder=False,isPlayable=True);
 url=params.get('url').split('|');part=url[0];url=url[1:];
 url=[x for x in url if x!='lnk'];q=[tit+'[COLOR=green]('+x+')[/COLOR]' for x in url];tip=[x for x in url];
 if len(q)==0: exec(nolink);sys.exit();
 y=[];y=[baseurl+part+'|'+x for x in url];#print q
 try:
  link=q;index=0;ch=0;
  index=plugintools.selector(link,title="[COLOR=blue][B]Por[COLOR=yellow]tal[COLOR=red] TV[/B][/COLOR]");
  ch=y[index];
  if ch:
   if index > -1: par={"tit":link[index],"tip":tip[index],"url":ch};portro3(par);
 except KeyboardInterrupt: pass;
 except IndexError: raise;

def portro3(params):
 tit=re.sub('(\[.*?\])','',params.get('tit'));tip=params.get('tip');url=params.get('url');
 if tip=='rds': exec(pxmess);
 ref=baseurl;body='';jar='';body,jar=cric2(url,ref,body,jar);
 tips={'sop':'SopAddress"\svalue="([^"]+)','vlc':'type="application\/x-vlc-plugin".*?target="([^"]+)','rds':'jwplayer\("playe?r?"\).*?file:\s\'?"?([^\'"]+)',
 'jw6':'jwplayer\("playe?r?"\).*?file:\s\'?"?([^\'"]+)','voy':'jwplayer\("playe?r?"\).*?file:\s\'?"?([^\'"]+)','ifr':'<iframe.*?src="([^"]+)'}
 r=tips[tip];y=plugintools.find_single_match(body,r);#print y
 if tip=='ifr': params={"tit":tit,"url":y,"ref":url,'reg':r};y=portro4(params);
 if tip=='sop': exec(dlg);xbmc.executebuiltin('XBMC.RunPlugin("plugin://plugin.video.p2p-streams/?url='+y+'&mode=2&name='+tit+'")')
 else: direct_play(y);#plugintools.play_resolved_url(y);#plugintools.direct_play(y);
 sys.exit();
 
def portro4(params):
 tit=params.get('tit');ref=params.get('ref');url=params.get('url');
 p={'u-stream':'<iframe.*?src="(http:\/\/micast[^"]+)','peaktv':'','cricfree':'(id|width|height|src)="?\'?([^"\']+)','goo\.gl':''};
 ##########
 '''
 s=[i for i in p if url.find(i)>0][0];r=p[s];params={"tit":tit,"url":url,"ref":ref,'reg':r,'pars':s.replace('-','')};#print '***',r,s,params
 y=eval(params['pars'])(params);
 return y;
 '''
 ###########
 try:
  s=[i for i in p if url.find(i)>0][0];r=p[s];params={"tit":tit,"url":url,"ref":ref,'reg':r,'pars':s.replace('-','')};#print '***',r,s,params
  y=eval(params['pars'])(params);
  return y;
 except: exec(messs);sys.exit()

def d_decode(str):
    decoded = "";
    for i in range (len(str)):
	 print str[i],ord(str[i])
	 b = ord(str[i]);#print '********** ',chr(b);#int(valt[ord(valx[p]) b = ord(str.charAt(i));
	 a = b^123;
	 decoded = decoded + chr(a)
    print 'DECODED****************',decoded
    return decoded
 
def cricfree(params):
 tit=params.get('tit');ref=params.get('ref');url=params.get('url');r=params.get('reg');body='';jar='';
 body,jar=cric2(url,ref,body,jar);ref=url;
 try:
  r='(id|width|height|src)="?\'?([^"\';]+)';w=plugintools.find_multiple_matches(body,r);w=w[:4];
  if w[3][1].find('theactionlive')>0:
   url='http://theactionlive.com/livegamecr.php?id='+w[0][1]+'&width='+w[1][1]+'&height='+w[2][1]+'&stretching='
   body,jar=cric2(url,ref,body,jar);ref=url;
   r='(id|width|height|src)="?\'?([^"\']+)';w=plugintools.find_multiple_matches(body,r);w=w[:4];
   url='http://biggestplayer.me/streamcr.php?id='+w[0][1]+'&width='+w[1][1]+'&height='+w[2][1]
   body,jar=cric2(url,ref,body,jar);ref=url;
   r='flashvars="file=([^\&]+).*?streamer=([^&]+)';w=plugintools.find_multiple_matches(body,r);
   y=w[0][1]+' playpath='+w[0][0]+' swfUrl=http://bernardotv.club/atdedead.swf live=1 token=#atd%#$ZH pageUrl='+ref;return y;#print url
  elif w[3][1].find('flashtv')>0:
   url='http://www.flashtv.co/embed.php?live='+w[0][1];body,jar=cric2(url,ref,body,jar);
   r='.*?SWFObject\(\'?"?([^\'"]+).*?file[\'"][:,]\s*[\'"]([^\'"]+).*?[\'"]streamer[\'"][:,]\s*[\'"]([^\'"]+)'
   w=plugintools.find_multiple_matches(body,r);
   y=w[0][2]+' playpath='+w[0][1]+' swfUrl=http://www.flashtv.co'+w[0][0]+' pageUrl='+url+' token=%ZZri(nKa@#Z timeout=10';return y;
  else: exec(messs);sys.exit();
 except: exec(nolink);sys.exit();
 
def ustream(params):
 tit=params.get('tit');ref=params.get('ref');url=params.get('url');r=params.get('reg');
 try: body='';jar='';body,jar=cric2(url,ref,body,jar);ref=url;url=plugintools.find_single_match(body,r);print url
 except: exec(messs);sys.exit();
 body,jar=cric2(url,ref,body,jar);r='var str = \'(rtmp[^;]+)';w=plugintools.find_single_match(body,r).split("'");w=filter(None,w);
 r='"([^"]+)';y=plugintools.find_single_match(w[1],r);
 y=w[0]+d_decode(str(y))+w[2]+' swfUrl=http://micast.tv/jwplayer/jwplayer.flash.swf pageUrl='+url;#print y
 #y='rtmp://89.248.168.21'+w[2]+' swfUrl=http://micast.tv/jwplayer/jwplayer.flash.swf pageUrl='+url;
 #y='rtmp://mica.st/origin/_definst_/digi11xDg swfUrl=http://micast.tv/jwplayer/jwplayer.flash.swf pageUrl='+url;
 #y='rtmp://89.248.168.21'+w[2];y='rtmp://mica.st:1935/origin/_definst_/'+w[2];
 #y=w[0]+d_decode(str(y))+w[2];#print y
 return y
 sys.exit();