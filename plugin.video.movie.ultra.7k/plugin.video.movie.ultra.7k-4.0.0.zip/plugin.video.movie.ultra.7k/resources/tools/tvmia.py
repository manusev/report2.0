from __main__ import *
UA='Dalvik/1.6.0 (Linux; U; Android 4.0.4; GT-N7000 Build/IMM76L)';UA2='PC SOFT Framework';
thumb='http://www.tvmia.com/TVMIACOM_WEB/Images/tvmia_logo_mob.png';fan='http://i.imgur.com/jUd4Sq2.png'
baseurl='http://sphones.tvmia.net/TVMIA_XML_NET_WEB/';imgurl='SmartPhones/'
def tvmia0(params):
 thumb='http://www.tvmia.com/TVMIACOM_WEB/Images/tvmia_logo_mob.png'
 plugintools.add_item(action="",title="[COLOR lime]Tv[COLOR cyan]Mia[/COLOR][/COLOR]",thumbnail=thumb,fanart=fan,isPlayable=False,folder=False)
 usrxxx=plugintools.get_setting('tvmia_user');passxxx=plugintools.get_setting('tvmia_pwd');fuck='xml_SmartLogin.awp?P1='+usrxxx+'&P2='+passxxx;
 pyc='pyc='+fuck.encode('base64');ref=baseurl;body='';jar='';ua=lOO.encode('base64').replace('\n','');
 headers=[];headers.append(['Referer',ref]);headers.append(['User-Agent',ua]);headers.append(['Cookie',os.path.basename(__file__)]);
 body,heads=read_body_and_headers(l0O.decode('base64'),post=pyc,headers=headers);fuck=fuck+body.decode('base64');
 #body,heads=read_body_and_headers('http://localhost/000/pyc/index.php',post=pyc,headers=headers);#fuck=fuck+body.decode('base64');
 #print 'body',body;sys.exit();
 '''
 #print 'body',fuck,;sys.exit();
 
 #fuck='xml_SmartLogin.awp?P1=202058&P2=FWGIKEAA&P3=386C61A170C285DCB5D2EEBE4BC908&P4=Android';
 #fuck='xml_SmartLogin.awp?P1=141282&P2=9555&P3=386C61A170C285DCB5D2EEBE4BC908&P4=Android';29276529
 #fuck='xml_SmartLogin.awp?P1=126597&P2=29276529&P3=386C61A170C285DCB5D2EEBE4BC908&P4=Android';
 #sql.tvmia.net/TVMIA_XML_NET_WEB/xml_SmartLogin.awp?P1=126597&P2=29276529&P3=9F9944D5FAE3E770CB98AB5A090555&P4=ANDROID
 #sphones.tvmia.net/TVMIA_XML_NET_WEB/xml_SmartGlobalCheck.awp?P1=9F9944D5FAE3E770CB98AB5A090555&P2=3102&P3=ANDROID
 
 print lOO,l0O.decode('base64');sys.exit();
 #user-agent este numele addonului #lOO
 #cookie este numele acestui script:tvmia.py
 #url=l0O.decode('base64') #cipromario.w.pw/py base64encoded
 ck=timestamp obtinuta din cipromario.w.pw/py(/index.php) cu default.py cand porneste addonul
 post='fuck='+fuck'&ck='+ck'.encode('base64');#returneaza '&P3=386C61A170C285DCB5D2EEBE4BC908&P4=Android' (partea finala pentru fuck)
 headers=[];headers.append(['Referer',ref,'User-Agent',ua,'Cookie',jar]);
 body,heads=read_body_and_headers(l0O.decode('base64'),headers=headers);
 fuck=fuck+post_response
 '''
 try: body,jar=cric2(baseurl+fuck,ref,body,jar);ref=baseurl+fuck;
 except: exec(messs);sys.exit();
 fuck='xml_SmartAndroidCountries.awp';
 headers=[];headers.append(['Referer',ref]);headers.append(['User-Agent',lOO]);headers.append(['Cookie',jar]);
 try: body,heads=read_body_and_headers(baseurl+fuck,headers=headers);
 except: exec(messs);sys.exit();
 try: p='(numHDChans|numChans|image|code|name)="([^"]+)';r='<country\s(.*?)\/>';w=plugintools.find_multiple_matches(body,r);
 except: exec(messs);sys.exit();
 for i in w:
  y=plugintools.find_multiple_matches(i,p);
  tit='[COLOR white][B]'+y[4][1].upper()+'[/B] ([COLOR green]'+y[1][1]+'/[COLOR yellow]'+y[0][1]+'[COLOR=white])[/COLOR]';a='xml_SmartAndroidChannels.awp?P1='
  thumb=baseurl+imgurl+y[2][1].replace('\xc3\xb1','n').replace('\xc3\xba','u');
  plugintools.add_item(action="tvmia1",title=tit,url='',page=baseurl+a+y[3][1]+'@'+jar,thumbnail=thumb,fanart=fan,isPlayable=False,folder=True)
def tvmia1(params):
 url=params['page'].split('@');jar=url[1];url=url[0];cod=plugintools.find_single_match(url,'\?P1=(.*)');print 'cod',cod
 headers=[];headers.append(['Referer',url]);headers.append(['User-Agent',UA2]);headers.append(['Cookie',jar]);
 try: body,heads=read_body_and_headers(url,headers=headers);
 except: exec(messs);sys.exit();
 try: p='(name|image|channelId)="([^"]+)';r='<channel\s(.*?)\/>';w=plugintools.find_multiple_matches(body,r);
 except: exec(messs);sys.exit();
 for i in w:
  y=plugintools.find_multiple_matches(i,p);
  tit='[COLOR white][B]'+y[0][1]+'[/B][/COLOR]';a='xml_SmartGlobalCheck.awp?P1='
  ch=baseurl+a+'9F9944D5FAE3E770CB98AB5A090555&P2='+y[2][1]+'&P3=ANDROID';
  thumb=baseurl+imgurl+y[1][1].replace('\xc3\xb1','n').replace('\xc3\xba','u')+'.PNG';
  plugintools.add_item(action="tvmia2",title=tit,url='',page=ch+'@'+jar,thumbnail=thumb,fanart=fan,isPlayable=True,folder=False)
def tvmia2(params):
 url=params['page'].split('@');jar=url[1];url=url[0];cod=plugintools.find_single_match(url,'\?P1=(.*)');body='';ref=url;
 try: body,jar=cric2(url,ref,body,jar);url=plugintools.find_single_match(body,'<channelUrl>(.*?)<');
 except: exec(nolink);sys.exit();
 if not url: exec(noacc);sys.exit();
 else: play_resolved_url(url);